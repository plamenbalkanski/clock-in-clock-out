using Microsoft.EntityFrameworkCore;
using TimeClockApi.Data;
using TimeClockApi.Models;

namespace TimeClockApi.Services
{
    public class TimeClockService : ITimeClockService
    {
        private readonly ApplicationDbContext _context;

        public TimeClockService(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<TimeClockEntry> ClockIn(int employeeId, string location)
        {
            var entry = new TimeClockEntry
            {
                EmployeeId = employeeId,
                ClockInTime = DateTime.UtcNow,
                Location = location
            };

            _context.TimeClockEntries.Add(entry);
            await _context.SaveChangesAsync();
            return entry;
        }

        public async Task<TimeClockEntry> ClockOut(int employeeId)
        {
            var entry = await _context.TimeClockEntries
                .Where(e => e.EmployeeId == employeeId && e.ClockOutTime == null)
                .OrderByDescending(e => e.ClockInTime)
                .FirstOrDefaultAsync();

            if (entry == null)
                throw new Exception("No active clock-in found");

            entry.ClockOutTime = DateTime.UtcNow;
            await _context.SaveChangesAsync();
            return entry;
        }

        public async Task<IEnumerable<TimeClockEntry>> GetEmployeeEntries(int employeeId)
        {
            return await _context.TimeClockEntries
                .Where(e => e.EmployeeId == employeeId)
                .OrderByDescending(e => e.ClockInTime)
                .ToListAsync();
        }
    }
} 