namespace TimeClockApi.Services
{
    public interface ITimeClockService
    {
        Task<TimeClockEntry> ClockIn(int employeeId, string location);
        Task<TimeClockEntry> ClockOut(int employeeId);
        Task<IEnumerable<TimeClockEntry>> GetEmployeeEntries(int employeeId);
    }
} 